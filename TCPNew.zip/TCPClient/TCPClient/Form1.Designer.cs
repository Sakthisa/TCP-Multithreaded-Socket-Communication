﻿namespace TCPClient
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.port = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.address = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.messageBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.startClient = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ClientLog = new System.Windows.Forms.RichTextBox();
            this.sendButton = new System.Windows.Forms.Button();
            this.Test = new System.Windows.Forms.TextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.button1 = new System.Windows.Forms.Button();
            this.sendFileButton = new System.Windows.Forms.Button();
            this.CheckUsername = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // port
            // 
            this.port.Location = new System.Drawing.Point(96, 35);
            this.port.Name = "port";
            this.port.Size = new System.Drawing.Size(170, 20);
            this.port.TabIndex = 7;
            this.port.Text = "8888";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(52, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Port";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "IP Address";
            // 
            // address
            // 
            this.address.Location = new System.Drawing.Point(96, 9);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(170, 20);
            this.address.TabIndex = 4;
            this.address.Text = "127.0.0.1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(7, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Username";
            // 
            // nameBox
            // 
            this.nameBox.Location = new System.Drawing.Point(96, 61);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(170, 20);
            this.nameBox.TabIndex = 9;
            this.toolTip1.SetToolTip(this.nameBox, "Client name");
            // 
            // messageBox
            // 
            this.messageBox.Location = new System.Drawing.Point(96, 87);
            this.messageBox.Name = "messageBox";
            this.messageBox.Size = new System.Drawing.Size(170, 20);
            this.messageBox.TabIndex = 10;
            this.toolTip1.SetToolTip(this.messageBox, "Message sent to server");
            this.messageBox.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(16, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 20);
            this.label4.TabIndex = 11;
            this.label4.Text = "Message";
            this.label4.Visible = false;
            // 
            // startClient
            // 
            this.startClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startClient.Location = new System.Drawing.Point(272, 9);
            this.startClient.Name = "startClient";
            this.startClient.Size = new System.Drawing.Size(163, 46);
            this.startClient.TabIndex = 12;
            this.startClient.Text = "Start Client";
            this.startClient.UseVisualStyleBackColor = true;
            this.startClient.Click += new System.EventHandler(this.startClient_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::TCPClient.Properties.Resources.Cross;
            this.pictureBox1.Location = new System.Drawing.Point(536, -3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(52, 41);
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBox1, "Determines if client is connected");
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(441, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 20);
            this.label6.TabIndex = 15;
            this.label6.Text = "Client Status";
            this.toolTip1.SetToolTip(this.label6, "Determines if client is connected");
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(517, 87);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 20);
            this.label5.TabIndex = 18;
            this.label5.Text = "Client Log";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // ClientLog
            // 
            this.ClientLog.Location = new System.Drawing.Point(393, 110);
            this.ClientLog.Name = "ClientLog";
            this.ClientLog.ReadOnly = true;
            this.ClientLog.Size = new System.Drawing.Size(318, 170);
            this.ClientLog.TabIndex = 17;
            this.ClientLog.Text = "";
            this.toolTip1.SetToolTip(this.ClientLog, "Client information");
            this.ClientLog.TextChanged += new System.EventHandler(this.ClientLog_TextChanged);
            // 
            // sendButton
            // 
            this.sendButton.Location = new System.Drawing.Point(272, 84);
            this.sendButton.Name = "sendButton";
            this.sendButton.Size = new System.Drawing.Size(74, 23);
            this.sendButton.TabIndex = 19;
            this.sendButton.Text = "Send";
            this.sendButton.UseVisualStyleBackColor = true;
            this.sendButton.Visible = false;
            this.sendButton.Click += new System.EventHandler(this.sendButton_Click);
            // 
            // Test
            // 
            this.Test.Location = new System.Drawing.Point(20, 158);
            this.Test.Name = "Test";
            this.Test.ReadOnly = true;
            this.Test.Size = new System.Drawing.Size(326, 20);
            this.Test.TabIndex = 21;
            this.toolTip1.SetToolTip(this.Test, "Path of file");
            this.Test.Visible = false;
            this.Test.WordWrap = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(20, 122);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(74, 30);
            this.button1.TabIndex = 22;
            this.button1.Text = "File Browser";
            this.toolTip1.SetToolTip(this.button1, "Pick a file to send to server");
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // sendFileButton
            // 
            this.sendFileButton.Location = new System.Drawing.Point(180, 122);
            this.sendFileButton.Name = "sendFileButton";
            this.sendFileButton.Size = new System.Drawing.Size(166, 30);
            this.sendFileButton.TabIndex = 23;
            this.sendFileButton.Text = "Send File to Server";
            this.toolTip1.SetToolTip(this.sendFileButton, "Send the file using path to the server");
            this.sendFileButton.UseVisualStyleBackColor = true;
            this.sendFileButton.Visible = false;
            this.sendFileButton.Click += new System.EventHandler(this.sendFileButton_Click);
            // 
            // CheckUsername
            // 
            this.CheckUsername.Location = new System.Drawing.Point(272, 59);
            this.CheckUsername.Name = "CheckUsername";
            this.CheckUsername.Size = new System.Drawing.Size(74, 23);
            this.CheckUsername.TabIndex = 24;
            this.CheckUsername.Text = "Check";
            this.toolTip1.SetToolTip(this.CheckUsername, "Checks username availability");
            this.CheckUsername.UseVisualStyleBackColor = true;
            this.CheckUsername.Visible = false;
            this.CheckUsername.Click += new System.EventHandler(this.CheckUsername_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(726, 298);
            this.Controls.Add(this.CheckUsername);
            this.Controls.Add(this.sendFileButton);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Test);
            this.Controls.Add(this.sendButton);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ClientLog);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.startClient);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.messageBox);
            this.Controls.Add(this.nameBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.port);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.address);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Client";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox port;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox address;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.TextBox messageBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button startClient;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox ClientLog;
        private System.Windows.Forms.Button sendButton;
        private System.Windows.Forms.TextBox Test;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button sendFileButton;
        private System.Windows.Forms.Button CheckUsername;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

