﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCPClient
{
    public partial class Form1 : Form
    {
        Socket client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp); //Client Socket
        string sendData = ""; //Variable holding the message sent from the client to the server

        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void ServerStatus_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void ClientLog_TextChanged(object sender, EventArgs e)
        {

        }

        public void appendtextName(string value)
        {
            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(appendtextName), new object[] { value }); //LOOK THIS UP
                return;
            }
            nameBox.Text = value;
        }

        private void startClient_Click(object sender, EventArgs e) //Ensures that the username entry is not blank
        {
            if (nameBox.Text == string.Empty)
            {
                ClientLog.Text += "Please Enter a Username!\n";
            }
            else
            {
                nameBox.ReadOnly = true;
                ClientStart();
            }
        }

        private void ClientStart() //Connects a client with the server
        {

            IPEndPoint ipEnd = new IPEndPoint(IPAddress.Parse(address.Text), Int32.Parse(port.Text)); //Need IP address of server to connect client to it
            client.Connect(ipEnd); //Connect the client to the server based on the ip address and port
            startClient.Visible = false;
            address.ReadOnly = true;
            string containName = "A";
            port.ReadOnly = true;
            sendData = nameBox.Text;
            client.Send(System.Text.Encoding.UTF8.GetBytes(sendData));
            byte[] contain = new byte[1];
            client.Receive(contain);
            containName = System.Text.Encoding.UTF8.GetString(contain);
            if(containName == "A")
            {
                nameBox.Text = string.Empty;
                ClientLog.Text += "Username Already Taken! Please Enter a New Username!";
                nameBox.ReadOnly = false;
                CheckUsername.Visible = true;
            }
            else
            {
                pictureBox1.BackgroundImage = Properties.Resources.Checkmark;
                nameBox.Text = sendData;
                ClientLog.Text += "Welcome " + sendData + "!\n";
                nameBox.ReadOnly = true;
                label4.Visible = true;
                messageBox.Visible = true;
                sendButton.Visible = true;
                button1.Visible = true;
                sendFileButton.Visible = true;
                Test.Visible = true;
                if (CheckUsername.Visible == true)
                {
                    CheckUsername.Visible = false;
                }
            }

        }

        private void sendButton_Click(object sender, EventArgs e) //Sends a message to the server and allow receives piggyback data sent back to the client from the server
        {
                //Sending server a message
                client.Send(new byte[1] { 66 });
                if (messageBox.Text == string.Empty)
                {
                    sendData = "Nothing";
                }
                else
                {
                    sendData = messageBox.Text;
                }

                client.Send(System.Text.Encoding.UTF8.GetBytes(sendData)); //One byte character or 8-bit character (UTF-8) text sent to server
                messageBox.Text = string.Empty;

                //Get piggyback data
                byte[] pbd = new byte[100]; //Holds piggyback data
                client.Receive(pbd); //Client receives piggyback data from server
                ClientLog.Text += "The Server says: " + System.Text.Encoding.UTF8.GetString(pbd) + "\n";
                ClientLog.Text += "\n";

        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e) //File browser
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                System.IO.StreamReader sr = new System.IO.StreamReader(openFileDialog1.FileName);
                MessageBox.Show(sr.ReadToEnd());
                sr.Close();
            }
        }

        private void button1_Click_1(object sender, EventArgs e) //File browser
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Test.Text = openFileDialog1.FileName;
            }
        }

        private void sendFileButton_Click(object sender, EventArgs e) //Allows particular file to be send to server
        {
            if(Test.Text == string.Empty)
            {
                button1_Click_1(sender, e);
            }
            client.Send(new byte[1] { 65 });
            string filename = Path.GetFileName(Test.Text);
            client.Send(System.Text.Encoding.UTF8.GetBytes(filename));
            byte[] content = File.ReadAllBytes(@"" + Test.Text);
            //client.SendFile(Test.Text);
            client.Send(BitConverter.GetBytes(content.Length));
            if(content.Length < 50000)
            {
                client.SendFile(Test.Text);
            }
            else
            {
                int aa = client.Send(content);
            }
            //int aa = client.Send(content);
            //Console.WriteLine("sent " + aa.ToString());
            byte[] pbd = new byte[100]; //Holds piggyback data
            client.Receive(pbd); //Client receives piggyback data from server
            ClientLog.Text += "The Server says: " + System.Text.Encoding.UTF8.GetString(pbd) + "\n";
            ClientLog.Text += "\n";
        }

        private void CheckUsername_Click(object sender, EventArgs e) //Checks whether username is available or not
        {
            string containName = "A";
            sendData = nameBox.Text;
            byte[] contain = new byte[1];
            client.Send(System.Text.Encoding.UTF8.GetBytes(sendData));
            client.Receive(contain);
            containName = System.Text.Encoding.UTF8.GetString(contain);
            if (containName == "A")
            {
                nameBox.Text = string.Empty;
                ClientLog.Text += "Username Already Taken! Please Enter a New Username!";
                nameBox.ReadOnly = false;
                CheckUsername.Visible = true;
            }
            else
            {
                pictureBox1.BackgroundImage = Properties.Resources.Checkmark;
                nameBox.Text = sendData;
                ClientLog.Text += "Welcome " + sendData + "!\n";
                nameBox.ReadOnly = true;
                label4.Visible = true;
                messageBox.Visible = true;
                sendButton.Visible = true;
                button1.Visible = true;
                sendFileButton.Visible = true;
                Test.Visible = true;
                if(CheckUsername.Visible == true)
                {
                    CheckUsername.Visible = false;
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
