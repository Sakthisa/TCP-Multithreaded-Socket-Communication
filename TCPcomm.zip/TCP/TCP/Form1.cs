﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCP
{
    public partial class Form1 : Form
    {
        string[] name = new string[1000];
        string[] log = new string[1000];
        byte[] sData;
        int clientAmount = 0;
        int nameContain = 0;
        string guest;
        int guestAmount = 0;
        Hashtable nameDatabase = new Hashtable();
        Stopwatch timer = new Stopwatch();
        double elapsedTime = 0;

        public Form1()
        {
            InitializeComponent();
        }

        public void appendtextList(string value) //Allows to append client names to client list 
        {
            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(appendtextList), new object[] {value}); //LOOK THIS UP
                return;
            }
            ClientList.Items.Add("Client: " + value  + "\n");
        }

        public void appendtextLog(string value) //Allows to append client messages to client logs
        {

            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(appendtextLog), new object[] { value }); //LOOK THIS UP
                return;
            }
            ClientLog.Text += value + " Says: ";
        }

        public void appendtextLog2(string value) //Allows to append client messages to client logs
        {

            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(appendtextLog2), new object[] { value }); //LOOK THIS UP
                return;
            }
            ClientLog.Text += value;
        }


        public void appendtextLog5(string value) //Allows to append client message speed in kilobytes per second to client logs
        {

            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(appendtextLog5), new object[] { value }); //LOOK THIS UP
                return;
            }
            ClientLog.Text += " [KB/S: " + value +    "]";
            ClientLog.Text += "\n";
        }

        public void appendtextLog3(string value) //Allows to append successful file transfer between client and server
        {

            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(appendtextLog3), new object[] { value }); //LOOK THIS UP
                return;
            }
            ClientLog.Text += "Successful file transfer from " + value + "!";
        }

        public void appendtextLog4(string value) //Allows to append to client logs when a new client connects
        {

            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(appendtextLog4), new object[] { value }); //LOOK THIS UP
                return;
            }
            ClientLog.Text += value + " Connected!\n";
        }

        public void appendtextSend() //Allows to send a message back to the client when the server has received the message from the client
        {
            if (SendClient.Text == string.Empty)
            {
                sData = new byte[8];
                sData = System.Text.Encoding.UTF8.GetBytes("Nothing!");
            }
            else
            {
                sData = new byte[System.Text.Encoding.UTF8.GetByteCount(SendClient.Text)];
                sData = System.Text.Encoding.UTF8.GetBytes(SendClient.Text);
            }
        }

        public void appendFolderCreate(string value) //Creates a folder if the folder is not already present
        {

            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(appendFolderCreate), new object[] { value }); //LOOK THIS UP
                return;
            }
            folderChooser.Text = value;
            FolderPath.Text = value;
            openFileDialog1.InitialDirectory = folderChooser.Text;
        }


        public void appendfilePath(string value) //Default Pathway that can be changed in order to change a folder
        {

            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(appendfilePath), new object[] { value }); //LOOK THIS UP
                return;
            }
            openFileDialog1.InitialDirectory = @"C:\Users\Sachin\Desktop\Test\";
        }



        public void appendfileSend() //Send message to client when a successful file transfer has been completed
        {
            sData = new byte[System.Text.Encoding.UTF8.GetByteCount("File Transfer Successful!")];
            sData = System.Text.Encoding.UTF8.GetBytes("File Transfer Successful!");
        }

        public void appendtextAccept(string value)
        {

            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(appendtextLog), new object[] { value }); //LOOK THIS UP
                return;
            }
        }

        public void appendtextDisconnected(string value) ////Allows to append to client logs when a client disconnects
        {
            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(appendtextDisconnected), new object[] { value }); //LOOK THIS UP
                return;
            }
            ClientLog.Text += value + " Disconnected.\n";
            for(int i = ClientList.Items.Count - 1; i >= 0; --i)
            {
                string removelist = "Client: " + value;
                if (ClientList.Items[i].ToString().Contains(removelist))
                {
                    ClientList.Items.RemoveAt(i);
                }
            }
            clientAmount--;
            Console.WriteLine("Client amount: " + clientAmount.ToString());
            if (clientAmount == 0)
            {
                appendtextAccept("OFFLINE");
                ClientList.Text = string.Empty;
            }
        }


        void SampleFunction()
        {
            Socket listenerSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp); //Server Socket
            IPEndPoint ipEnd = new IPEndPoint(IPAddress.Parse(address.Text), Int32.Parse(port.Text)); //IP address of server and PORT
            listenerSocket.Bind(ipEnd); //Bind the server and ip/port information, essentially binding server to localhost

            while (true) //Loop will continue to listen to new connections and accept new incoming clients
            {
                listenerSocket.Listen(0); //Server is in a waiting mode where it waits for the client to connect to the server
                Socket clientSocket = listenerSocket.Accept(); //Client socket and server connection is established and sends byte arrays back and forth, connection is successful

                //threads
                Thread clientThread; //Create multithread client, makes a new client thread
                clientThread = new Thread(() => ClientConnection(clientSocket, clientAmount, listenerSocket)); //Multithreading with accepted client socket
                clientThread.Start(); //Start threading
                clientAmount++; //Client number numeration
                Console.WriteLine("Client amount: " + clientAmount.ToString());
            }
        }

        public int hashfunction() //Simple hashfunction that allows name to be stored within a hashtable
        {
            return nameContain++;

        }


        private void startServer_Click(object sender, EventArgs e) //Starts the ser
        {
            if (address.Text == string.Empty || port.Text == string.Empty)
            {
                MessageBox.Show("Need both a valid IP address and Port");
            }
            new Thread(SampleFunction).Start();
            appendtextAccept("ONLINE");
            pictureBox1.BackgroundImage = Properties.Resources.Checkmark;
            address.ReadOnly = true;
            port.ReadOnly = true;
            startServer.Visible = false;
        }

        private void ClientConnection(Socket clientSocket, int clientNo, Socket listenerSocket)
        {
            pictureBox1.BackgroundImage = Properties.Resources.Checkmark;
            byte[] Buffer = new byte[clientSocket.SendBufferSize]; //Client decides the size of buffer
            byte[] fileBuffer = new byte[1024 * 5000];
            byte[] contain = new byte[1];
            int readByte = 0; //Data from the client in bytes
            int nameByte = clientSocket.Receive(Buffer);
            byte[] nameData = new byte[nameByte];
            Array.Copy(Buffer, nameData, nameByte);
            while (nameDatabase.ContainsValue(System.Text.Encoding.UTF8.GetString(nameData)))
            {
                    clientSocket.Send(new byte[1] { 65 });
                    nameByte = clientSocket.Receive(Buffer);
                    nameData = new byte[nameByte];
                    Array.Copy(Buffer, nameData, nameByte);
            }
            if (!System.Text.Encoding.UTF8.GetString(nameData).Contains("Guest"))
                {
                    clientSocket.Send(new byte[1] { 66 });
                    nameDatabase.Add(hashfunction(), System.Text.Encoding.UTF8.GetString(nameData));
                    name[clientNo] = System.Text.Encoding.UTF8.GetString(nameData);
                    appendtextList(System.Text.Encoding.UTF8.GetString(nameData));
                }
                else
                {
                    guestAmount++;
                    guest = System.Text.Encoding.UTF8.GetString(nameData) + clientAmount;
                    Console.WriteLine("Guest names: " + guest);
                    name[clientNo] = System.Text.Encoding.UTF8.GetString(nameData) + clientAmount;
                    appendtextList(System.Text.Encoding.UTF8.GetString(nameData) + clientAmount);
                }
            appendtextLog4(System.Text.Encoding.UTF8.GetString(nameData));
                do
            {
                //Receive
                try
                {
                    if (clientSocket.Connected)
                    {
                        clientSocket.Receive(contain);
                        if (System.Text.Encoding.UTF8.GetString(contain) == "A")
                        {
                            readByte = clientSocket.Receive(Buffer);
                            Console.WriteLine("Byte Amount: " + readByte);
                            string path =  Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments) + @"\ClientFiles";
                            byte[] file = new byte[readByte]; //received data from client not the additional bits not received, readByte gives us the exact byte size of the message sent from the client
                            Array.Copy(Buffer, file, readByte);
                            Console.WriteLine(System.Text.Encoding.UTF8.GetString(file));
                            byte[] data1 = new byte[1024];
                            clientSocket.Receive(data1);
                            int filesize = BitConverter.ToInt32(data1, 0);
                            Console.WriteLine("FileSize: " + filesize);
        
                            byte[] data = new byte[clientSocket.ReceiveBufferSize];
                            int i = 0;
                            double fileSpeed = 0.0;
                            if (clientSocket.Connected)
                            {
                                if(folderChooser.Text == string.Empty)
                                {
                                    DirectoryInfo di = Directory.CreateDirectory(path);
                                    appendFolderCreate(path);
                                }
                                FileStream fs = new FileStream(@"" + Path.Combine(folderChooser.Text, System.Text.Encoding.UTF8.GetString(file)), FileMode.Create, FileAccess.ReadWrite);
                                BinaryWriter writer = new BinaryWriter(fs);
                                long fileSize = 0;
                                timer.Start();
                                while(fileSize != filesize)
                                {
                                    i = clientSocket.Receive(data);
                                    fileSize = fileSize + i;
                                    Console.WriteLine("Bytes: " + fileSize);
                                    writer.Write(data, 0, i);

                                }
                                Console.WriteLine("NewSize: " + fileSize);
                                fs.Close();
                                timer.Stop();
                                elapsedTime = timer.Elapsed.TotalSeconds;
                                double fileSizeKB = (double)fileSize / 1000.0;
                                fileSpeed = (fileSizeKB) / (elapsedTime);
                                fileSpeed = Math.Truncate(fileSpeed);
                            }
                            appendtextLog3(System.Text.Encoding.UTF8.GetString(nameData));
                            appendtextLog5(fileSpeed.ToString());
                            appendfileSend();
                            clientSocket.Send(sData); //Data sent back to client (piggyback data)
                        }
                        if (System.Text.Encoding.UTF8.GetString(contain) == "B")
                        {
                            //Do stuff with data
                            timer.Start();
                            readByte = clientSocket.Receive(Buffer);
                            timer.Stop();
                            Console.WriteLine("Message Size in Bytes: " + readByte.ToString());
                            elapsedTime = timer.Elapsed.TotalSeconds;
                            Console.WriteLine("Time: " + elapsedTime.ToString());
                            double messageSize = (double)readByte / 1000.0;
                            Console.WriteLine("Message Size in KiloBytes: " + messageSize.ToString());
                            Console.WriteLine("(KB/S): " + (messageSize / (elapsedTime)).ToString());
                            double bandwithMesage = (messageSize) / (elapsedTime);
                            bandwithMesage = Math.Truncate(bandwithMesage);
                            byte[] rData = new byte[readByte]; //received data from client not the additional bits not received, readByte gives us the exact byte size of the message sent from the client
                            Array.Copy(Buffer, rData, readByte); //Copy Buffer information to the destination which is rData and only copy the message from the client which can be identified using readByte (# of bytes in message)
                            Console.WriteLine("We got: (" + System.Text.Encoding.UTF8.GetString(nameData) + ") " + System.Text.Encoding.UTF8.GetString(rData)); //Displays message from client by turning the converting the client message byte into a string to be displayed by the server
                            log[clientNo] = System.Text.Encoding.UTF8.GetString(rData);
                            appendtextLog(System.Text.Encoding.UTF8.GetString(nameData));
                            appendtextLog2(System.Text.Encoding.UTF8.GetString(rData));
                            appendtextLog5(bandwithMesage.ToString());
                            appendtextSend();
                            clientSocket.Send(sData); //Data sent back to client (piggyback data)
                        }

                    }
                }
                catch(System.Net.Sockets.SocketException e)
                {
                    if(System.Text.Encoding.UTF8.GetString(nameData) == "Guest")
                    {
                        guestAmount--;
                        appendtextDisconnected(guest);
                    }
                    else
                    {
                        appendtextDisconnected(System.Text.Encoding.UTF8.GetString(nameData));
                    }
                }


            } while (readByte > 0); //As long as we have data from the client continue the loop
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void ClientList_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                FolderPath.Text = openFileDialog1.FileName;
            }
        }

        private void FolderPath_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if(folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                folderChooser.Text = folderBrowserDialog1.SelectedPath + @"\";
                openFileDialog1.InitialDirectory = folderChooser.Text;
                FolderPath.Text = folderChooser.Text;
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
