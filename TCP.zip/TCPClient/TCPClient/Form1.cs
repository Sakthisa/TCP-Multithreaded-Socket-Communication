﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCPClient
{
    public partial class Form1 : Form
    {
        Socket client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp); //Client Socket
        string sendData = ""; //Variable holding the message sent from the client to the server

        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void ServerStatus_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void ClientLog_TextChanged(object sender, EventArgs e)
        {

        }

        public void appendtextName(string value)
        {
            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(appendtextName), new object[] { value }); //LOOK THIS UP
                return;
            }
            nameBox.Text = value;
        }

        private void startClient_Click(object sender, EventArgs e)
        {
            IPEndPoint ipEnd = new IPEndPoint(IPAddress.Parse(address.Text), Int32.Parse(port.Text)); //Need IP address of server to connect client to it
            client.Connect(ipEnd); //Connect the client to the server based on the ip address and port
            pictureBox1.BackgroundImage = Properties.Resources.Checkmark;
            address.ReadOnly = true;
            port.ReadOnly = true;
            if(nameBox.Text == string.Empty || nameBox.Text == "Guest")
            {
                nameBox.Text = "Guest";
                sendData = "Guest";
            }
            else
            {
                sendData = nameBox.Text;
            }
            nameBox.ReadOnly = true;
            client.Send(System.Text.Encoding.UTF8.GetBytes(sendData));
            byte[] nd = new byte[System.Text.Encoding.UTF8.GetByteCount(sendData)];
            byte[] contain = new byte[1];
            client.Receive(nd);
            client.Receive(contain);
            if (System.Text.Encoding.UTF8.GetString(contain) == "A")
            {
                ClientLog.Text += "Welcome Back " + System.Text.Encoding.UTF8.GetString(nd) + "!\n";
            }
            if (System.Text.Encoding.UTF8.GetString(contain) == "B")
            {
                ClientLog.Text += " Welcome " + System.Text.Encoding.UTF8.GetString(nd) + "!\n";
            }

        }

        private void sendButton_Click(object sender, EventArgs e)
        {
                //Sending server a message
                client.Send(new byte[1] { 66 });
                if (messageBox.Text == string.Empty)
                {
                    sendData = "Nothing";
                }
                else
                {
                    sendData = messageBox.Text;
                }

                client.Send(System.Text.Encoding.UTF8.GetBytes(sendData)); //One byte character or 8-bit character (UTF-8) text sent to server
                messageBox.Text = string.Empty;

                //Get piggyback data
                byte[] pbd = new byte[100]; //Holds piggyback data
                client.Receive(pbd); //Client receives piggyback data from server
                ClientLog.Text += "The Server says: " + System.Text.Encoding.UTF8.GetString(pbd) + "\n";
                ClientLog.Text += "\n";

        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                System.IO.StreamReader sr = new System.IO.StreamReader(openFileDialog1.FileName);
                MessageBox.Show(sr.ReadToEnd());
                sr.Close();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Test.Text = openFileDialog1.FileName;
            }
        }

        private void sendFileButton_Click(object sender, EventArgs e)
        {
            client.Send(new byte[1] { 65 });
            client.SendFile(Test.Text);
            Test.Text = string.Empty;
            byte[] pbd = new byte[100]; //Holds piggyback data
            client.Receive(pbd); //Client receives piggyback data from server
            ClientLog.Text += "The Server says: " + System.Text.Encoding.UTF8.GetString(pbd) + "\n";
            ClientLog.Text += "\n";
        }
    }
}
